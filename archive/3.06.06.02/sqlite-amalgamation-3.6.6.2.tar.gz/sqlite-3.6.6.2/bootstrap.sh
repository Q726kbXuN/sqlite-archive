
cp /usr/share/automake-1.9/install-sh .
cp /usr/share/automake-1.9/missing .
cp /usr/share/automake-1.9/INSTALL .
cp /usr/share/automake-1.9/depcomp .
cp /usr/share/automake-1.9/config.sub .
cp /usr/share/automake-1.9/config.guess .
cp /usr/share/libtool/ltmain.sh .

aclocal
autoconf
automake

