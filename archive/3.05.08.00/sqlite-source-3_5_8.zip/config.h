/*
** 2008 March 6
**
** The author disclaims copyright to this source code.  In place of
** a legal notice, here is a blessing:
**
**    May you do good and not evil.
**    May you find forgiveness for yourself and forgive others.
**    May you share freely, never taking more than you give.
**
*************************************************************************
** Default configuration header in case the 'configure' script is not used
**
** @(#) $Id: config.h,v 1.1 2008/03/20 02:25:35 mlcreech Exp $
*/
#ifndef _CONFIG_H_
#define _CONFIG_H_

/* We do nothing here, since no assumptions are made by default */

#endif
